
from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
import requests
import os
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import zipfile
import tempfile
import io

app = Flask(__name__)
CORS(app)

@app.route("/pack", methods=["POST"])
def pack_website():
    data = request.json
    url = data.get("url")
    filetype = data.get("filetype")
    filename = data.get("filename", "output")
    raw = data.get("raw", False)

    if not url:
        return jsonify({"error": "Missing URL"}), 400

    try:
        r = requests.get(url)
        r.raise_for_status()
        html_content = r.text
    except Exception as e:
        return jsonify({
            "error": str(e),
            "explanation": "Basically if you be uneducated its: " + str(e)
        }), 500

    parsed_url = urlparse(url)
    host = parsed_url.netloc.replace('.', '_')

    with tempfile.TemporaryDirectory() as tmpdir:
        if filetype == "html":
            if raw:
                soup = BeautifulSoup(html_content, "html.parser")
                scripts = soup.find_all("script", src=True)
                for s in scripts:
                    try:
                        src = s["src"]
                        raw_js = requests.get(src if src.startswith("http") else f"{url}/{src}").text
                        inline = soup.new_tag("script")
                        inline.string = raw_js
                        s.replace_with(inline)
                    except:
                        continue
                html_content = str(soup)

            filepath = os.path.join(tmpdir, f"{filename}.html")
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(html_content)

        elif filetype == "js":
            js_file = os.path.join(tmpdir, f"{filename}.js")
            with open(js_file, "w", encoding="utf-8") as f:
                f.write(f"// JavaScript wrapper for {url}\n")
                f.write(f"document.write(`{html_content}`);")

        elif filetype == "py":
            py_file = os.path.join(tmpdir, f"{filename}.py")
            with open(py_file, "w", encoding="utf-8") as f:
                f.write(f"# Python version for {url}\n")
                f.write("html = '''\n")
                f.write(html_content)
                f.write("\n'''
print(html)")

        zip_buf = io.BytesIO()
        with zipfile.ZipFile(zip_buf, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(tmpdir):
                for file in files:
                    full_path = os.path.join(root, file)
                    zipf.write(full_path, os.path.relpath(full_path, tmpdir))

        zip_buf.seek(0)
        return send_file(zip_buf, mimetype="application/zip", as_attachment=True, download_name=f"{filename}_{host}.zip")

@app.route("/")
def home():
    return {"status": "INTWIAAFSR backend ready 🤠"}

if __name__ == "__main__":
    app.run(port=5050)
